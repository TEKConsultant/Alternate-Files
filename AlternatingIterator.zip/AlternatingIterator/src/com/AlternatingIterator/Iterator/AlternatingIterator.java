package com.AlternatingIterator.Iterator;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class AlternatingIterator<String> implements Iterator {

    private Iterator<String>[] iterators;

    /**The index of iterator, which has the next element.*/
    private int nextIterator = 0;

    public AlternatingIterator(Iterator<String> ... iterators) {
        this.iterators = iterators;

        if (!iterators[0].hasNext())
            findNextIterator();
    }

    @Override
    public boolean hasNext() {
        return iterators[nextIterator].hasNext();
    }

    @Override
    public Object next() {
    	String element = iterators[nextIterator].next();

        findNextIterator();

        return element;
    }

    void findNextIterator() {
        int currentIterator = nextIterator;

        do {
            stepNextIterator();
        } while (!iterators[nextIterator].hasNext() && nextIterator != currentIterator);
    }

    private void stepNextIterator() {
        nextIterator = (nextIterator + 1) % iterators.length;
    }
    
    

}