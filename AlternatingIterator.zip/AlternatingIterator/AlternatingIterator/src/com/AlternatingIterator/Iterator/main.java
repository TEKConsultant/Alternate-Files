package com.AlternatingIterator.Iterator;

import java.util.ArrayList;
import java.util.Iterator;

public class main {

	@SuppressWarnings("unchecked")
	public static void main(String[] args) {
		ArrayList<String> color_list = new ArrayList<String>(7);
		Iterator<String> color_Iter;

		color_list.add("a");
		color_list.add("b");
		color_list.add("c");
		color_Iter = color_list.iterator();

		ArrayList<String> color_list1 = new ArrayList<String>(7);
		Iterator<String> color_Iter1;

		color_list1.add("1");
		color_list1.add("2");
		color_Iter1 = color_list1.iterator();

		ArrayList<String> color_list2 = new ArrayList<String>(7);
		Iterator<String> color_Iter2;

		color_list2.add("x");
		color_list2.add("y");
		color_list2.add("z");
		color_Iter2 = color_list2.iterator();
		System.out.println("Iterators list are : ");
		AlternatingIterator a2 = new AlternatingIterator<>(color_Iter,color_Iter1, color_Iter2);	while (a2.hasNext()) {
			System.out.println(a2.next());
	
	}

	}

}
